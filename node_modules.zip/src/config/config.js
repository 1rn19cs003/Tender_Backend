 const config={
    secret_jwt:"this is my secret key",
    emailUser:'abhigrmr@gmail.com',
    emailPassword:'skqifhegoixeqotn'
}
module.exports=config